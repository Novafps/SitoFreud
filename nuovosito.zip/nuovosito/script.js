document.addEventListener('DOMContentLoaded', () => {
    const cartButton = document.createElement('button');
    cartButton.innerHTML = 'Carrello (0)';
    cartButton.id = 'cart-button';
    cartButton.className = 'cart-button';
    document.body.appendChild(cartButton);

    const cartContainer = document.getElementById('shopping-cart');
    let isCartOpen = false;
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

    function updateCartButton() {
        const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
        cartButton.innerHTML = `Carrello (${totalItems})`;
    }

    function renderCart() {
        if (!isCartOpen) return;

        const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
        
        cartContainer.innerHTML = `
            <div class="cart-content">
                <h2>Il Tuo Carrello</h2>
                ${cartItems.length === 0 ? '<p class="cart-empty">Il tuo carrello è vuoto.</p>' : ''}
                ${cartItems.map(item => `
                    <div class="cart-item">
                        <span>${item.name}</span>
                        <span>€${item.price.toFixed(2)}</span>
                        <div>
                            <button onclick="updateQuantity(${item.id}, -1)">-</button>
                            <span>${item.quantity}</span>
                            <button onclick="updateQuantity(${item.id}, 1)">+</button>
                        </div>
                        <button onclick="removeItem(${item.id})">Rimuovi</button>
                    </div>
                `).join('')}
                ${cartItems.length > 0 ? `
                    <div class="cart-total">Totale: €${total.toFixed(2)}</div>
                    <div class="action-buttons">
                        <button onclick="clearCart()">Svuota Carrello</button>
                        <button onclick="checkout()">Checkout</button>
                    </div>
                ` : ''}
            </div>
        `;
    }

    function toggleCart() {
        isCartOpen = !isCartOpen;
        if (isCartOpen) {
            renderCart();
            cartContainer.style.display = 'block';
        } else {
            cartContainer.style.display = 'none';
        }
    }

    function addToCart(id, name, price) {
        const existingItem = cartItems.find(item => item.id === id);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cartItems.push({ id, name, price, quantity: 1 });
        }
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        updateCartButton();
        renderCart();
    }

    function updateQuantity(id, change) {
        const item = cartItems.find(item => item.id === id);
        if (item) {
            item.quantity = Math.max(0, item.quantity + change);
            if (item.quantity === 0) {
                removeItem(id);
            } else {
                localStorage.setItem('cartItems', JSON.stringify(cartItems));
                updateCartButton();
                renderCart();
            }
        }
    }

    function removeItem(id) {
        cartItems = cartItems.filter(item => item.id !== id);
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        updateCartButton();
        renderCart();
    }

    function clearCart() {
        cartItems = [];
        localStorage.removeItem('cartItems');
        updateCartButton();
        renderCart();
    }

    function checkout() {
        alert('Funzionalità di checkout non implementata in questo esempio.');
    }

    cartButton.addEventListener('click', toggleCart);

    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', (e) => {
            const { id, name, price } = e.target.dataset;
            addToCart(parseInt(id), name, parseFloat(price));
        });
    });

    window.updateQuantity = updateQuantity;
    window.removeItem = removeItem;
    window.clearCart = clearCart;
    window.checkout = checkout;

    updateCartButton();
});